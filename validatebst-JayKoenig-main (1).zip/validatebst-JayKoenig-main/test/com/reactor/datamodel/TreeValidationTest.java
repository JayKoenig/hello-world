package com.reactor.datamodel;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Tests for Tree Validation - check if keys are in order in a BST
 * STUDENT MUST MODIFY isTreeOutOfOrderADAPTER()
 * STUDENT SHOULD NOT change any other code in here.
 */
public class TreeValidationTest {

    /**
     * THESE ITEMS WILL BE SET UP BY '@Before'
     */
    public MyTreeMap<String, Integer> testMap;
    private MyTreeMap<String, Integer>.Node testRootNode;
    private MyTreeMap<String, Integer>.Node Try6, Try14, Try8, Try3;

    /**
     * ADAPTER METHOD - STUDENTS ARE TO UPDATE THIS TO CALL THEIR tree check code
     *
     * @param root - root node of a tree to validate
     * @return true if keys are out of order
     */
    Boolean isTreeOutOfOrderADAPTER(MyTreeMap<String, Integer>.Node root) {

        /**
         * STUDENTS: Call your method here and RETURN APPROPRIATE VALUE
         * e.g.:     return myTreeCheckerReturnsTrueIfTreeIsBad(root);
         * OR:		 return ! myTreeCheckerReturnsFalseIfTreeIsBad(root);
         */
        return null; // STUDENTS: replace this as per above
    }

    @Test
    public void normalTree() {
        Boolean treeHasProblem;

        // Normal tree
        treeHasProblem = isTreeOutOfOrderADAPTER(testRootNode);
        assertFalse("expected no problem", treeHasProblem);
    }


    @Test
    public void badTree6to8_R7bad() {
        String saveK;
        Boolean treeHasProblem;

        saveK = Try6.key;
        Try6.key = "08";
        System.out.println("\n");
        treeHasProblem = isTreeOutOfOrderADAPTER(testRootNode);

        assertTrue("expected problem on bad: " + Try6.key, treeHasProblem);
        Try6.key = saveK;
    }


    @Test
    public void badTree14to12_L13bad() {
        String saveK;
        Boolean treeHasProblem;

        saveK = Try14.key;
        Try14.key = "12";
        System.out.println("\n");
        treeHasProblem = isTreeOutOfOrderADAPTER(testRootNode);

        assertTrue("expected problem on bad: " + Try14.key, treeHasProblem);
        Try14.key = saveK;
    }


    @Test
    public void badTree8to2_ROOT3bad() {
        String saveK;
        Boolean treeHasProblem;

        saveK = Try8.key;
        Try8.key = "02";
        System.out.println("\n");
        treeHasProblem = isTreeOutOfOrderADAPTER(testRootNode);

        assertTrue("expected problem on bad: " + Try8.key, treeHasProblem);
        Try8.key = saveK;
    }


    @Test
    public void badTree3to33_L6bad_rightUnderRoot() {
        String saveK;
        Boolean treeHasProblem;

        saveK = Try3.key;
        Try3.key = "33";
        System.out.println("\n");
        treeHasProblem = isTreeOutOfOrderADAPTER(testRootNode);

        assertTrue("expected problem on bad: " + Try3.key, treeHasProblem);
        Try3.key = saveK;
    }


    /**
     * set up a tree with 9 nodes same as example in Think Data Structures textbook.
     * @throws Exception
     */
    @Before
    public void setUp() throws Exception {
        testMap = new MyTreeMap<String, Integer>();
        MyTreeMap<String, Integer>.Node node08 = testMap.makeNode("08", 8);

        MyTreeMap<String, Integer>.Node node03 = testMap.makeNode("03", 3);
        MyTreeMap<String, Integer>.Node node10 = testMap.makeNode("10", 10);
        node08.left = node03;
        node08.right = node10;

        MyTreeMap<String, Integer>.Node node01 = testMap.makeNode("01", 1);
        MyTreeMap<String, Integer>.Node node06 = testMap.makeNode("06", 6);
        MyTreeMap<String, Integer>.Node node14 = testMap.makeNode("14", 14);
        node03.left = node01;
        node03.right = node06;
        node10.right = node14;

        MyTreeMap<String, Integer>.Node node04 = testMap.makeNode("04", 4);
        MyTreeMap<String, Integer>.Node node07 = testMap.makeNode("07", 7);
        MyTreeMap<String, Integer>.Node node13 = testMap.makeNode("13", 13);
        node06.left = node04;
        node06.right = node07;
        node14.left = node13;

        testMap.setTree(node08, 9);

        testRootNode = node08;

        Try6 = node06;
        Try14 = node14;
        Try8 = node08;
        Try3 = node03;
    }
}


/*  CANONICAL TEST RESULT
VISIT key: 08
VISIT key: 03
VISIT key: 01
VISIT key: 06
VISIT key: 04
VISIT key: 07
VISIT key: 10
VISIT key: 14
VISIT key: 13     (mjc all visited, no prob)


VISIT key: 08
VISIT key: 03
VISIT key: 01
VISIT key: 08     (mjc the '6' has an 8')


VISIT key: 08
VISIT key: 03
VISIT key: 01
VISIT key: 06
VISIT key: 04
VISIT key: 07
VISIT key: 10
VISIT key: 12     (mjc the 14 has a 12)


VISIT key: 02   (the 8 has a 2)


 */
