package com.reactor.userInterface;

import com.reactor.datamodel.AnomalyCache;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 * Main class for Reactor Manager, which initializes data and GUI.
 */
public class ReactorManagerApp {
    RadiationChart radiationChart;
    AnomalyCache anomalyCache = new AnomalyCache();

    /**
     * main program
     *
     * @param args NONE
     */
    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ReactorManagerApp().display();
            }
        });
    }

    /**
     * create and display the GUI items which will be visible and active
     */
    private void display() {
        JFrame appFrame = new JFrame("ReactorChart");           // Main Window
        appFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        radiationChart = new RadiationChart(12);            // Radiation chart on top
        appFrame.add(radiationChart.createRadiationChart(), BorderLayout.NORTH);

        JPanel displayPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));   // General Display
        appFrame.add(displayPanel, BorderLayout.SOUTH);

        // Add controls to display
        addControls(displayPanel);

        appFrame.pack();
        appFrame.setLocationRelativeTo(null);
        appFrame.setVisible(true);
    }

    /**
     * add various controls such as buttons to the main display panel
     *
     * @param displayPanel
     */
    private void addControls(JPanel displayPanel) {
        displayPanel.add(new JButton(new AbstractAction("Slower") {
            @Override
            public void actionPerformed(ActionEvent e) {
                radiationChart.increaseInterval();
            }
        }));

        displayPanel.add(new JButton(new AbstractAction("Faster") {
            @Override
            public void actionPerformed(ActionEvent e) {
                radiationChart.decreaseInterval();
            }
        }));

        displayPanel.add(new JButton(new AbstractAction("*Break Tree*") {
            @Override
            public void actionPerformed(ActionEvent e) {
                anomalyCache.breakTree();
            }
        })).setForeground(Color.RED);
    }
}