package com.reactor.userInterface;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

/**
 * The radiation chart about the reactor, currently displaying random data.
 * Usage requires constructor for data, and then call createRadiationChart()
 */
public class RadiationChart {

    final XYSeries series;
    final Timer intervalTimer;
    final JFreeChart chart;
    private final int initialEntries;
    private final Random random;
    private int interval = 1000;

    /**
     * Construct necessary data, timer for updates and internal representation of chart
     *
     * @param initEntries
     */
    public RadiationChart(int initEntries) {
        initialEntries = initEntries;
        this.random = new Random();

        // Consruct initial data
        series = new XYSeries("Data");
        for (int i = 0; i < random.nextInt(initialEntries) + initialEntries / 2; i++) {
            series.add(i, random.nextGaussian());
        }
        XYSeriesCollection dataset = new XYSeriesCollection(series);
        chart = ChartFactory.createXYLineChart("Test", "Time", "Picocuries", dataset, PlotOrientation.VERTICAL, false, false, false);

        intervalTimer = new Timer(interval, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                series.add(series.getItemCount(), random.nextGaussian());
            }
        });
    }

    /**
     * create a panel with chart in it
     *
     * @return a specialized JPanel for charting
     */
    ChartPanel createRadiationChart() {
        intervalTimer.start();

        return new ChartPanel(chart) {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(480, 240);
            }
        };
    }

    /**
     * Slow down the updates of data/chart
     */
    void increaseInterval() {
        interval *= 2;
        intervalTimer.setDelay(interval);
    }

    /**
     * Speed up the updates of data/chart
     */
    public void decreaseInterval() {
        interval /= 2;
        intervalTimer.setDelay(interval);
    }
}
