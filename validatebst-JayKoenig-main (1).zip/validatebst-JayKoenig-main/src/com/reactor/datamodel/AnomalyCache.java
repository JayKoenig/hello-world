package com.reactor.datamodel;

/**
 * Maintain collection of anomalies that have aoccured since reactor started up.
 * This uses sample data same as Test class - from "Think Data Structures" textbook.
 */
public class AnomalyCache {

    static MyTreeMap<String, Integer> map;
    static MyTreeMap<String, Integer>.Node rootNode;

    /**
     * Construct a binary search tree Manually
     */
    public AnomalyCache() {
        MyTreeMap<String, Integer> anomalyMap = new MyTreeMap<String, Integer>();
        MyTreeMap<String, Integer>.Node node08 = anomalyMap.makeNode("08", 8);

        MyTreeMap<String, Integer>.Node node03 = anomalyMap.makeNode("03", 3);
        MyTreeMap<String, Integer>.Node node10 = anomalyMap.makeNode("10", 10);
        node08.left = node03;
        node08.right = node10;

        MyTreeMap<String, Integer>.Node node01 = anomalyMap.makeNode("01", 1);
        MyTreeMap<String, Integer>.Node node06 = anomalyMap.makeNode("06", 6);
        MyTreeMap<String, Integer>.Node node14 = anomalyMap.makeNode("14", 14);
        node03.left = node01;
        node03.right = node06;
        node10.right = node14;

        MyTreeMap<String, Integer>.Node node04 = anomalyMap.makeNode("04", 4);
        MyTreeMap<String, Integer>.Node node07 = anomalyMap.makeNode("07", 7);
        MyTreeMap<String, Integer>.Node node13 = anomalyMap.makeNode("13", 13);
        node06.left = node04;
        node06.right = node07;
        node14.left = node13;

        anomalyMap.setTree(node08, 9);

        map = anomalyMap;
        rootNode = node08;
    }

    /**
     * Utility method to get root of anomaly tree
     *
     * @return Returns root node, test data will have a key  of "08"
     */
    static MyTreeMap<String, Integer>.Node getRoot() {
        return rootNode;
    }

    /**
     * Break the BST by making some keys out of order
     */
    public void breakTree() {
        System.out.println("breakTree: rootNode.left.right.key  was: " + rootNode.left.right.key);
        rootNode.left.right.key = "08";
        System.out.println("breakTree: rootNode.left.right.key  SET: " + rootNode.left.right.key);

        System.out.println("breakTree: rootNode.right.right.key  was: " + rootNode.right.right.key);
        rootNode.right.right.key = "12";
        System.out.println("breakTree: rootNode.right.right.key  SET: " + rootNode.right.right.key);
    }

}