package com.reactor.datamodel;

import com.reactor.datamodel.MyTreeMap;

import java.io.*;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

public class MyTreeMapExample {
	
	public static void main(String[] args) {
		int n = 16384;
		System.out.println("\nTesting com.reactor.datamodel.MyTreeMap with random strings");
		putRandomStrings(n);

		System.out.println("\nTesting com.reactor.datamodel.MyTreeMap with timestamps");
		putTimestamps(n);

	}

	/**
	 * @param n 
	 */
	private static void putRandomStrings(int n) {
		// com.reactor.datamodel.MyTreeMap<String, Integer> map = new com.reactor.datamodel.MyTreeMap<String, Integer>();
		TreeMap<String, Integer> map = new TreeMap<String, Integer>();
		
		final long startTime = System.currentTimeMillis();		
		for (int i=0; i<n; i++) {
			String uuid = UUID.randomUUID().toString();
			map.put(uuid, 0);
		}
		final long elapsed = System.currentTimeMillis() - startTime;
		//printResults(map, elapsed, map.height());
		printResults(map, elapsed, -1);
	}
	
	/**
	 * @param n 
	 */
	private static void putTimestamps(int n) {
		//com.reactor.datamodel.MyTreeMap<String, Integer> map = new com.reactor.datamodel.MyTreeMap<String, Integer>();
		TreeMap<String, Integer> map = new TreeMap<String, Integer>();

		final long startTime = System.currentTimeMillis();		
		for (int i=0; i<n; i++) {
			String timestamp = Long.toString(System.nanoTime());
			map.put(timestamp, 0);
		}
		final long elapsed = System.currentTimeMillis() - startTime;
		//printResults(map, elapsed, map.height());
		printResults(map, elapsed, -1);
	}
	
	/**
	 * @param map
	 * @param elapsed
	 */
	private static void printResults(Map<String, Integer> map, final long elapsed, int height) {
		System.out.println("    Time in milliseconds = " + (elapsed));
		System.out.println("    Final size of com.reactor.datamodel.MyTreeMap = " + map.size());
		System.out.println("    log base 2 of size of com.reactor.datamodel.MyTreeMap = " + Math.log(map.size()) / Math.log(2));
		System.out.println("    Final height of com.reactor.datamodel.MyTreeMap = " + height);
	}
	/**
	 * @param n 
	 */
	@SuppressWarnings("unused")
	private static void putWordList(int n) {
		// assemble the file name
		String slash = File.separator;
		String filename = System.getProperty("user.dir") + slash + 
				"src" + slash + "resources" + slash + "words.txt";
				
	    MyTreeMap<String, Integer> map = new MyTreeMap<String, Integer>();
	    
	    final long startTime = System.currentTimeMillis();
		try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
		    String line;
		    int i = 0;
			while ((line = br.readLine()) != null) {
		    	map.put(line, 0);
		    	
		    	i++;
		    	if (i >= n) {
		    		break;
		    	}
		    }
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		final long elapsed = System.currentTimeMillis() - startTime;
		printResults(map, elapsed, map.height());
	}
}
