# DS2 Exercise from Midterm question #7

Note to Class: Uses older/outdated JUnit 4.  

In MyTreeMapTest you must update the isTreeOutOfOrderADAPTER() method, which is an 'adapter'
that all the tests will call to validate a tree. It needs to call your tree validator
method and return an appropriate boolean as defined by the adapter.
